=========================================
==        PR4: Ticket de salida        ==
=========================================

== Inicio obligatorio ===================

Inmediatamente después de extraer el paquete y antes de modificar el Makefile, ejecutar desde el directorio que contiene este README.txt:

    ./scripts/check.sh

El servidor debe reconocer el rol y registrar el primer intento con nota 0. Cada punto vale 25%. Se permiten entregas incompletas y reintentos durante la evaluación. Se conserva la mejor nota.

== Contexto =============================

Un taller planifica la reparación de bicicletas. Para saber si alcanza la cantidad de repuestos, un programa recibe dos enteros en una línea: la cantidad disponible y la solicitada, ambas expresadas en repuestos. El programa informa el saldo después de descontar lo solicitado. Un saldo negativo indica cuánto falta.

Los archivos .c y .h de code/ ya están completos. main.c coordina tres módulos: uno lee la entrada, otro calcula el saldo y el último imprime el informe. El directorio tests/ contiene cuatro pares de archivos .in y .expected; scripts/tests-run.sh ejecuta las pruebas. El único archivo que se debe modificar es code/Makefile. La plantilla incluye las variables y los targets all y clean, con comentarios que indican qué falta completar.

== 1. Construir el ejecutable ===========

Desde code/, abrir el Makefile con Vim. Completar las variables, la dependencia de all, la regla de enlace y la regla patrón de compilación. Tanto make como make all deben generar resumen_taller en el directorio actual. Utilizar gcc con -Wall -Wextra -Werror -std=c11 -g -O0. Compilar cada .c a su propio .o y enlazar los objetos. Cada línea de receta comienza con una tabulación. Comprobar el resultado con una de las entradas de tests/.

== 2. Reconstruir solo lo necesario =====

Incorporar la generación e inclusión de archivos .d con las dependencias de las cabeceras. Si no cambió ningún archivo, make no debe recompilar ni enlazar. Si cambia la fecha de un .c, solo debe actualizarse su objeto y repetirse el enlace. Repetir la comprobación con pedido_taller.h: deben recompilarse solo los módulos que incluyen esa cabecera, directamente o a través de otra cabecera.

== 3. Ejecutar las pruebas ==============

Agregar el target test al Makefile. Al ejecutar make test desde code/, debe construirse el ejecutable si hace falta y luego ejecutarse ../scripts/tests-run.sh, indicando la ruta al programa y ../tests. La suite debe informar cuatro PASS. Si una prueba falla, el target también debe terminar con un código de salida distinto de cero.

== 4. Limpiar los archivos generados ====

Completar la receta del target clean. Debe eliminar el ejecutable, los .o, los .d y las salidas .out, .err y .diff de los tests, incluso si solo existen algunos de estos archivos. Debe conservar el Makefile, los .c, los .h, los scripts y los pares .in y .expected. Incorporar test a la declaración .PHONY junto con all y clean.

== Revisar el intento ===================

Volver al directorio que contiene este archivo y ejecutar ./scripts/check.sh. El servidor informará el resultado de cada punto, la nota del intento, los intentos registrados y la nota final.
