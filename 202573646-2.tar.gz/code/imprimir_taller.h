#ifndef IMPRIMIR_TALLER_H
#define IMPRIMIR_TALLER_H

void imprimir_taller(int saldo);

#endif
