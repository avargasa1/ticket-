#ifndef CALCULAR_TALLER_H
#define CALCULAR_TALLER_H

#include "pedido_taller.h"

int calcular_taller(Pedido p);

#endif
