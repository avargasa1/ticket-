#include "leer_taller.h"
#include "calcular_taller.h"
#include "imprimir_taller.h"
int main(void) {
    Pedido p;
    if (!leer_taller(&p)) return 1;
    imprimir_taller(calcular_taller(p));
    return 0;
}
