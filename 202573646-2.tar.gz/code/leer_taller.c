#include <stdio.h>
#include "leer_taller.h"
int leer_taller(Pedido *p) {
    return scanf("%d %d", &p->disponible, &p->solicitado) == 2;
}
