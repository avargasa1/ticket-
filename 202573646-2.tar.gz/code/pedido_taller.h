#ifndef PEDIDO_TALLER_H
#define PEDIDO_TALLER_H

typedef struct { int disponible, solicitado; } Pedido;

#endif
