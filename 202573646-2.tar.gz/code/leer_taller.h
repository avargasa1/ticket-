#ifndef LEER_TALLER_H
#define LEER_TALLER_H

#include "pedido_taller.h"

int leer_taller(Pedido *p);

#endif
