#include <stdio.h>
#include "imprimir_taller.h"
void imprimir_taller(int saldo) {
    printf("Saldo (%s): %d\n", "repuestos", saldo);
}
