#include "calcular_taller.h"
int calcular_taller(Pedido p) {
    return p.disponible - p.solicitado;
}
