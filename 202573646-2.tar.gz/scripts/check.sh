#!/usr/bin/env bash

set -u

SCRIPT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
ROOT_DIR="$(dirname -- "${SCRIPT_DIR}")"
ROL="202573646-2"
ENDPOINT="${PR4_ENDPOINT:-https://api.ptoledo.org/courses/utfsm/inf20125l/20262/pr4/validation}"

printf '%s\n' '========================================='
printf '%s\n' '==      Verificación Ticket PR4        =='
printf '%s\n' '========================================='
printf '\n'

CURL_FORMS=(--form "check=1")
if [[ -f "${ROOT_DIR}/code/Makefile" ]]; then
    CURL_FORMS+=(--form "makefile=@${ROOT_DIR}/code/Makefile;type=text/plain")
fi

RESPONSE_FILE="$(mktemp)" || {
    printf 'ERRO:  No fue posible preparar la respuesta del servidor\n'
    exit 2
}
trap 'rm -f -- "${RESPONSE_FILE}"' EXIT

if ! HTTP_STATUS="$(curl -sS --max-time 45 \
    --request POST \
    --url "${ENDPOINT}?rol=${ROL}" \
    "${CURL_FORMS[@]}" \
    --output "${RESPONSE_FILE}" \
    --write-out '%{http_code}')"; then
    printf 'ERRO:  No fue posible contactar el validador remoto\n'
    exit 2
fi

cat -- "${RESPONSE_FILE}"

if [[ "${HTTP_STATUS}" != '200' ]]; then
    printf 'ERRO:  El validador respondió con código HTTP %s\n' "${HTTP_STATUS}"
    exit 2
fi
